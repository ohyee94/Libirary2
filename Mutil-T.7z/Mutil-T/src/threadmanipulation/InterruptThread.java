package threadmanipulation;

public class InterruptThread {
	public static void main(String[] args) {
		//(new InterruptThread()).new UglyRunnable();
		Thread thread1 = new Thread(new UglyRunnable());

		thread1.start();

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		thread1.interrupt();
	}

	private static class WaitRunnable implements Runnable {
		@Override
		public void run() {
			long t = System.currentTimeMillis();

			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				System.out.println("duration : "
						+ (System.currentTimeMillis() - t));
				System.out.println("The thread has been interrupted");
				System.out.println("The thread is interrupted : "
						+ Thread.currentThread().isInterrupted());
			}

			System.out.println("Current time millis : "
					+ System.currentTimeMillis());
		}
	}
	public static class UglyRunnable implements Runnable {
	    @Override
	    public void run() {
	        while(!Thread.currentThread().isInterrupted()){
	            //Heavy operation
	            try {
	                Thread.sleep(5000);
	            } catch (InterruptedException e) {
	            }
	            //Other operation
	        }
	        System.out.println("ugly done");
	    }
	}	
	
	
	/* An other thread want to interrupt your thread while your thread is sleeping. 
	 * The sleep will be interrupted, but the interrupted status will be cleared 
	 * so the loop will continue. A solution to make a better thread is to interrupt again the thread 
	 * after an InterruptedException
	 */
	public static class BetterRunnable implements Runnable {
	    @Override
	    public void run() {
	        while(!Thread.currentThread().isInterrupted()){
	            //Heavy operation
	            try {
	                Thread.sleep(5000);
	            } catch (InterruptedException e) {
	                Thread.currentThread().interrupt();
	            }
	            //Other operation
	        }
	        System.out.println("better done");
	        
	    }
	}	
}
