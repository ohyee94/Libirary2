package threadstate;
import java.util.Vector;
class Sender extends Thread {
	static final int MAXQUEUE = 5;
	private Vector<String> messages = new Vector<String>();
	@Override
	public void run() {
		try {
			while (true) {
				putMessage();
				sleep(900);
			}
		} catch (InterruptedException e) {
		}
	}
	private synchronized void putMessage() throws InterruptedException {
		while (messages.size() == MAXQUEUE) {
			System.out.println("Queue is full");
			wait();
		}
		messages.addElement(new java.util.Date().toString());
		notify();
	}
	public synchronized String getMessage() throws InterruptedException {
		notify();
		while (messages.size() == 0) {
			System.out.println("Queue is empty");
			wait();
		}
		String message = (String) messages.firstElement();
		messages.removeElement(message);
		return message;
	}
}
class Receiver extends Thread {
	Sender Sender;
	Receiver(Sender p) {
		Sender = p;
	}
	@Override
	public void run() {
		try {
			while (true) {
				String message = Sender.getMessage();
				System.out.println("Got message: " + message);
				sleep(1900);
			}
		} catch (InterruptedException e) {
		}
	}
	public static void main(String args[]) {
		Sender sender = new Sender();
		sender.start();
		new Receiver(sender).start();
		
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		new ThreadHandling(sender).start();
	}
}

class ThreadHandling extends Thread{
	
	private Sender sender;
	public ThreadHandling(Sender p) {
		this.sender = p;
	}
	
	@Override
	public void run() {
			while (true) {
				if (sender.getState()== Thread.State.WAITING) {
					sender.interrupt();
					if (sender.isInterrupted()) {
						System.out.println(sender.getState());
					}
				}
			}
	}	
}