package threadcreate;

class ImplementsRunnable implements Runnable {

	public void run() {
		for (int i = 0; i<3; i++)
			  System.out.println("[" + Thread.currentThread().getName() + "]" + i);
	}
}

public class RunVsStart {

	public static void main(String args[]) throws Exception {
		// Multiple threads share the same object.
		ImplementsRunnable rc = new ImplementsRunnable();
		Thread t1 = new Thread(rc);
		t1.setName("thread 1");
		t1.start(); // change to t1.run()
		Thread t2 = new Thread(rc);
		t2.setName("thread 2");
		t2.start();

	}
}

