package threadcreate;

class MyRunnable implements Runnable {
	private int counter = 0;
	public void run() {
		counter++;
		System.out.println("MyRunnable : Counter : " + counter);
	}
}
class MyThread extends Thread {
	private int counter = 0;
	public void run() {
		counter++;
		System.out.println("MyThread : Counter : " + counter);
	}
}
public class ThreadVsRunnable {
	public static void main(String args[]) throws Exception {
		// Multiple threads share the same object.
		MyRunnable rc = new MyRunnable();
		Thread t1 = new Thread(rc);
		t1.start();
		Thread.sleep(1000); // Waiting for 1 second before starting next thread
		Thread t2 = new Thread(rc);
		t2.start();

		// Creating new instance for every thread access.
		MyThread tc1 = new MyThread();
		tc1.start();
		Thread.sleep(1000); // Waiting for 1 second before starting next thread
		MyThread tc2 = new MyThread();
		tc2.start();
	}
}