package deadlock.case2;
public class Deadlock {
	public static void main(String[] args) {
		final Object A = "A";
		final Object B = "B";
		Runnable block1 = new Runnable() {
			@Override
			public void run() {
				synchronized (A) {
					System.out.println("Thread1: locked A");
					synchronized (B) {
						System.out.println("Thread1: locked B");
						try {
							A.wait();
							System.out.println("Thread1: re-acquired locked A");
						} catch (InterruptedException e) {
						}
						System.out.println("Thread1: unlocked B");
					}
					System.out.println("Thread1: unlocked A");
				}
			}
		};
		Runnable block2 = new Runnable() {
			@Override
			public void run() {
				synchronized (A) {
					System.out.println("Thread2: locked A");
					synchronized (B) {
						System.out.println("Thread2: locked B");
						System.out.println("Thread2: unlocked B");
					}
					System.out.println("Thread2: ulocked A");
				}
			}
		};
		Runnable block3 = new Runnable() {
			@Override
			public void run() {
				synchronized(this) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
					System.out.println("Thread3: called A.notify");
					A.notify();
				}
			}
		};
		Thread t1 = new Thread(block1);
		Thread t2 = new Thread(block2);
		Thread t3 = new Thread(block3);
		t1.start();
		t2.start();
		t3.start();
	}
}

