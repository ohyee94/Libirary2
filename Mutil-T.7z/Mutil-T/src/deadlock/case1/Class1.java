package deadlock.case1;
class Class1 {
	private Class2 inst2;
	synchronized void set_side_kick(Class2 inst2) {
		this.inst2 = inst2;
	}
	synchronized void to_the_bat_cave() {
		System.out.println("thread1:to_the_bat_cave locked inst1");
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		inst2.lets_go();
		System.out.println("thread1:to_the_bat_cave ulocked inst1");
	}
	synchronized void report(String s) {
		System.out.println("thread1:report locked inst1");
		System.out.println(s);
		System.out.println("thread1:report unlocked inst1");
	}
	public static void main(String[] a) {
		final Class1 inst1 = new Class1();
		final Class2 inst2 = new Class2(inst1);
		inst1.set_side_kick(inst2);
		Thread alfred = new Thread(new Runnable() {
			@Override
			public void run() {
				inst1.to_the_bat_cave();
			}
		});
		Thread joker = new Thread(new Runnable() {
			@Override
			public void run() {
				inst2.sock_bam();
			}
		});
		alfred.start();
		joker.start();
	}
}
class Class2 {
	private Class1 inst1;
	Class2(Class1 inst1) {
		this.inst1 = inst1;
	}
	synchronized void lets_go() {
		System.out.println("thread2:lets_go locked inst2");
		System.out.println("letgo");
		System.out.println("thread2:lets_go unlocked inst2");
	}
	synchronized void sock_bam() {
		System.out.println("thread2:sock_bam locked inst2");
		inst1.report("Ouch!");
		System.out.println("thread2:sock_bam unlocked inst2");
	}
}
