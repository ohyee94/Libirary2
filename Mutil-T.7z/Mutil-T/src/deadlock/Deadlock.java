package deadlock;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.concurrent.TimeUnit;

import deadlock.detector.DeadlockConsoleHandler;
import deadlock.detector.DeadlockDetector;

public class Deadlock {
	public static void main(String[] args) {
		
		DeadlockDetector deadlockDetector = new DeadlockDetector(new DeadlockConsoleHandler(), 5, TimeUnit.SECONDS);
		deadlockDetector.start();
		
		
		final Object A = new Object();
		final Object B = new Object();
		Runnable block1 = new Runnable() {
			@Override
			public void run() {
				synchronized (A) {
					System.out.println("Thread1: locked A" + A);
					synchronized (B) {
						System.out.println("Thread1: locked B");
						System.out.println("Thread1: unlocked B");
					}
					System.out.println("Thread1: unlocked A");
				}
			}
		};
		Runnable block2 = new Runnable() {
			@Override
			public void run() {
				synchronized (B) {
					System.out.println("Thread2: locked B" + B);
					synchronized (A) {
						System.out.println("Thread2: locked A");
						System.out.println("Thread2: unlocked A");
					}
					System.out.println("Thread2: ulocked B");
				}
			}
		};
		Thread t1 = new Thread(block1);
		Thread t2 = new Thread(block2);
		t1.start();
		t2.start();
//		detectDeadlock();
//		printDeadlockStackTrace();
	}

/*	private static void detectDeadlock() {
		ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
		long[] threadIds = threadBean.findMonitorDeadlockedThreads();
		int deadlockedThreads = threadIds != null ? threadIds.length : 0;
		System.out
				.println("Number of deadlocked threads: " + deadlockedThreads);
	}

	
	private static void printDeadlockStackTrace() {
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();

		long ids[] = bean.findMonitorDeadlockedThreads();

		if (ids != null) {
			ThreadInfo threadInfo[] = bean.getThreadInfo(ids);

			for (ThreadInfo threadInfo1 : threadInfo) {
				System.out.println("ThreadID:" + threadInfo1.getThreadId()); // Prints the ID
																// of deadlocked
																// thread

				System.out.println("ThreadName:" + threadInfo1.getThreadName()); // Prints the
																	// name of
																	// deadlocked
																	// thread

				System.out.println("Lock name:" + threadInfo1.getLockName()); // Prints the
																// string
																// representation
																// of an object
																// for which
																// thread has
																// entered into
																// deadlock.

				System.out.println("LockOwnerID:" + threadInfo1.getLockOwnerId()); // Prints the
																	// ID of
																	// thread
																	// which
																	// currently
																	// owns the
																	// object
																	// lock

				System.out.println("LockOwnername:" + threadInfo1.getLockOwnerName()); // Prints
																	// name of
																	// the
																	// thread
																	// which
																	// currently
																	// owns the
																	// object
																	// lock.
				System.out.println();
			}
		} else {
			System.out.println("No Deadlocked Threads");
		}
	}*/

}
