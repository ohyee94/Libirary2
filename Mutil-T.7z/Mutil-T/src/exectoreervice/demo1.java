package exectoreervice;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class demo1 {

	static String sub(String s, int a, int b) {
		String sb = "";
		for (int i =a; i<b; i++)
			sb += s.charAt(i);
		return sb;
	}
	public static void main(String[] args) {
		String s = "hello world";
		String sb = sub(s, 6,  11);
		
		System.out.println(sb);
		System.out.println(s.substring(6, 11));
		
		ExecutorService executorService = Executors.newFixedThreadPool(10);

		executorService.execute(new Runnable() {
		    public void run() {
		        System.out.println("Asynchronous task");
		    }
		});

		executorService.shutdown();
	}

}
