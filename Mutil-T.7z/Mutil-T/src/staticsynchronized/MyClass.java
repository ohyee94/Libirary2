package staticsynchronized;

public class MyClass {
	
	enum MethodType {
		syncInstanceMethod,
		nonSyncInstanceMethod,
		syncStaticMethod,
		nonSyncStaticMethod
	}
    /**
     * Method Id 1
     */
    public synchronized void syncInstanceMethod1() {
        System.out.println("sync instance method 1 call Start");
        makeThreadSleep();
        System.out.println("sync instance method 1 call Ended");
    }
 
    /**
     * Method Id 2
     */
    public synchronized void syncInstanceMethod2() {
        System.out.println("sync instance method 2 call Start");
        makeThreadSleep();
        System.out.println("sync instance method 2 call Ended");
    }
 
    /**
     * Method Id 3
     */
    public void nonSyncInstanceMethod() {
        System.out.println("non sync instance method call Start");
        System.out.println("non sync instance method call Ended");
    }
 
    /**
     * Method Id 4
     */
    public static synchronized void syncStaticMethod1() {
        System.out.println("sync static method 1 call Start");
        staticMakeThreadSleep();
        System.out.println("sync static method 1 call Ended");
    }
 
    /**
     * Method Id 5
     */
    public static synchronized void syncStaticMethod2() {
        System.out.println("sync static method 2 call Start");
        staticMakeThreadSleep();
        System.out.println("sync static method 2 call Ended");
    }
 
    /**
     * Method Id 6
     */
    public static void nonSyncStaticMethod() {
        System.out.println("non sync static method call Start");
        System.out.println("non sync static method call Ended");
    }
 
    private void makeThreadSleep() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
 
    private static void staticMakeThreadSleep() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
 
}