package staticsynchronized;

public class Main {
	 
    public static void main(String[] args) {
 
        MyClass myClass = new MyClass();
 
        /**
         * Scenario : 1 When one thread accessing synchronized instance method
         * at that time other threads can NOT access ANY synchronized instance
         * methods.
         */
        //int methodIdForThreadOne = 1;
        //int methodIdForThreadTwo = 2;
 
        /**
         * Scenario : 2 When one thread accessing synchronized instance method
         * at that time other threads can access ANY NON synchronized instance
         * methods.
         */
         int methodIdForThreadOne = 1;
         int methodIdForThreadTwo = 3;
 
        /**
         * Scenario : 3 When one thread accessing synchronized instance method
         * at that time other thread can access synchronized static methods.
         */
         //int methodIdForThreadOne = 1;
         //int methodIdForThreadTwo = 4;
 
        /**
         * Scenario : 4 When one thread accessing synchronized static method at
         * that time other threads can NOT access ANY synchronized static
         * methods.
         */
         //int methodIdForThreadOne = 4;
         //int methodIdForThreadTwo = 5;
 
        /**
         * Scenario : 5 When one thread accessing synchronized static method at
         * that time other threads can access ANY NON synchronized static
         * methods.
         */
        // int methodIdForThreadOne = 4;
        // int methodIdForThreadTwo = 6;
 
        MyThread myThreadOne = new MyThread("ONE", methodIdForThreadOne,
                myClass);
        MyThread myThreadTwo = new MyThread("TWO", methodIdForThreadTwo,
                myClass);
 
        myThreadOne.start();
        myThreadTwo.start();
 
    }
 
}