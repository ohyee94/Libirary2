package staticsynchronized;

class MyThread extends Thread {
	 
    private int methodId = 0;
    private MyClass myClass = null;
 
    public MyThread(String threadName, int methodId, MyClass myClass) {
        super(threadName);
        this.methodId = methodId;
        this.myClass = myClass;
    }
 
    @Override
    public void run() {
        switch (methodId) {
        case 1: {
            myClass.syncInstanceMethod1();
            break;
        }
        case 2: {
            myClass.syncInstanceMethod2();
            break;
        }
        case 3: {
            myClass.nonSyncInstanceMethod();
            break;
        }
        case 4: {
            MyClass.syncStaticMethod1();
            break;
        }
        case 5: {
            MyClass.syncStaticMethod2();
            break;
        }
        case 6: {
            MyClass.nonSyncStaticMethod();
            break;
        }
        }
    }
}