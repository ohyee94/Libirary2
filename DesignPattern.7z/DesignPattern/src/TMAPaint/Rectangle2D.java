package TMAPaint;

import java.awt.Color;
import java.awt.Graphics;

public class Rectangle2D extends AbstractRectangle{

	public Rectangle2D(int x, int y, int height, int width) {
		super(x, y, height, width);
		
	}

	@Override
	void draw(Graphics g) {
		g.setColor(Color.RED);
		g.fillRect(getX(), getY(), getHeight(), getWidth());

		super.draw(g);
	}
	

}
