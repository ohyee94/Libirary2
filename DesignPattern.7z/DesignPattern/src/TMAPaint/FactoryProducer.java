package TMAPaint;

public class FactoryProducer {
	public static enum typeFactory{
		F_2D, F_3D
	}
	public AbstractFactory getFactory(typeFactory type){
		if(type == typeFactory.F_2D)
			return new Factory2D();
		return new Factory3D();
	}
}
