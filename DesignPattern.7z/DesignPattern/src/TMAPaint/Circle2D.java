package TMAPaint;

import java.awt.Color;
import java.awt.Graphics;

public class Circle2D extends AbstractCircle{
	
	public Circle2D(int x, int y, int radius) {
		super(x, y, radius);
	}

	@Override
	void draw(Graphics g) {
		g.setColor(Color.YELLOW);	
		g.fillOval(getX(), getY(), getRadius(), getRadius());
		super.draw(g);
	}
}
