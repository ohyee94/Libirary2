package TMAPaint;

import java.awt.Color;
import java.awt.Graphics;

public class Rectangle3D extends AbstractRectangle{
	
	public Rectangle3D(int x, int y, int height, int width) {
		super(x, y, height, width);
	}
	@Override
	void draw(Graphics g) {
		g.setColor(Color.BLUE);

		g.fill3DRect(getX(), getY(), getHeight(), getWidth(), true);
		super.draw(g);
	}
}
