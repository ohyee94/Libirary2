package TMAPaint;

import java.util.List;

import javax.swing.table.AbstractTableModel;


public class TableCircle extends AbstractTableModel{
	 /**
	 * 
	 */

	String[] columnNames = {"Position", "Radius"};
	 Object[][] data;
	 
	 public TableCircle(List<AbstractCircle> listCircle) {
	  
	  int length = 0;
	  for (int i = 0; i < listCircle.size(); i++) {
	   
	    length++;
	   
	  }
	  data = new Object[length][2];
	  int i = 0;
	  for (AbstractCircle circle : listCircle) {
		  
	    data[i][0] = "(" + circle.getX() + ", " + circle.getY() + ")";
	    data[i][1] = circle.getRadius();
	    i++;
	   
	  }
	 }
	 
	 @Override
	 public int getRowCount() {
	  return data.length;
	 }

	 @Override
	 public int getColumnCount() {
	  return columnNames.length;
	 }

	 @Override
	 public Object getValueAt(int rowIndex, int columnIndex) {
	  return data[rowIndex][columnIndex];
	 }
	 
	 public String getColumnName(int col) {
	  return columnNames[col];
	 }

}
