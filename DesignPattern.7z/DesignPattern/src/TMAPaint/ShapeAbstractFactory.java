package TMAPaint;

public abstract class ShapeAbstractFactory{

	abstract AbstractCircle createCircle();
	abstract AbstractRectangle createRectangle();
	

}
