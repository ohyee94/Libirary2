package TMAPaint;

import java.awt.Graphics;

public interface Printer {
	
	
	
	public void print(PrintObject printedObject);
}
	class PrintObject{
		public void print(Graphics a){
			
	}
}
