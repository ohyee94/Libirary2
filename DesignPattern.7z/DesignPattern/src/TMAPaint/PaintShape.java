package TMAPaint;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Label;

import java.awt.Panel;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import com.thach.Ex6.CircleTable;
import com.thach.Ex6.RectangleTable;
import com.thach.Ex6.Shap;

import TMAPaint.FactoryProducer.typeFactory;
import TMAPaint.AbstractFactory.typeShape;




public class PaintShape {

	private JFrame frame;
	
	private Panel draw_panel;
	
	private JScrollPane circleScroll;
	private JScrollPane recScroll;
	
	private Point last;
	private Point present;
	private int x;
	private int y;
	//create ArrayListCircle
	public static List<AbstractCircle> listCircle = new ArrayList<>();
	public AbstractCircle circle;
	
	//create ArrayListRectangle
	public static List<AbstractRectangle> listRec = new ArrayList<>();;
	public AbstractRectangle rectangle;
	
	private JTable circle_table;
	private JTable rectangle_table;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaintShape window = new PaintShape();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PaintShape() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 690, 360);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		//Create Shape Panel
		Panel shape_panel = new Panel();
		shape_panel.setBackground(new Color(107, 142, 35));
		shape_panel.setForeground(Color.WHITE);
		shape_panel.setBounds(0, 0, 191, 322);
		frame.getContentPane().add(shape_panel);
		shape_panel.setLayout(null);
		
		//Create Circle Panel in Shape Panel
		JPanel circle_panel = new JPanel();
		circle_panel.setBounds(0, 0, 191, 159);
		circle_panel.setPreferredSize(new Dimension(160,150));
		shape_panel.add(circle_panel);
		circle_panel.setLayout(null);
		
		//Create Circle Label
		JLabel circle_label = new JLabel("Circle");
		circle_label.setBounds(10, 11, 38, 14);
		circle_label.setHorizontalAlignment(SwingConstants.LEFT);
		circle_label.setVerticalAlignment(SwingConstants.TOP);
		circle_panel.add(circle_label);
		
		//Create Circle Scroll
		circleScroll = new JScrollPane();
		circleScroll.setBounds(10, 36, 181, 112);
		circle_panel.add(circleScroll);
		
		//Create Circle Table
		circle_table = new JTable();
		circleScroll.setViewportView(circle_table);
		circle_table.setFont(new Font("TAHOMA", Font.BOLD, 12));
		
		
		
		//Create Rectangle Panel in Shape Panel
		JPanel rec_panel = new JPanel();
		rec_panel.setBounds(0, 158, 191, 164);
		rec_panel.setPreferredSize(new Dimension(180, 150));
		shape_panel.add(rec_panel);
		rec_panel.setLayout(null);
		
		//Create Rectangle Label
		JLabel rec_label = new JLabel("Rectangle");
		rec_label.setBounds(10, 11, 58, 14);
		rec_panel.add(rec_label);
		
		recScroll = new JScrollPane();
		recScroll.setBounds(10, 36, 181, 117);
		rec_panel.add(recScroll);
		
		
				
		//Create Rectangle Table
		rectangle_table = new JTable();
		recScroll.setViewportView(rectangle_table);
		
		
		
		//Create Button Panel
		Panel button_panel = new Panel();
		button_panel.setBounds(197, 0, 477, 76);
		frame.getContentPane().add(button_panel);
		button_panel.setBackground(new Color(75, 0, 130));
		button_panel.setLayout(null);
		
		//Create Add button
		final Button addButton = new Button("Add");
		addButton.setEnabled(true);
		addButton.setBounds(5, 10, 51, 22);
		addButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		button_panel.add(addButton);
		
		//Create Remove button
		Button removeButton = new Button("Remove");
		removeButton.setBounds(62, 10, 63, 22);
		removeButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Graphics g = draw_panel.getGraphics();
				if (!listCircle.isEmpty()) {
					if (circle_table.getSelectedRow() != -1) {
						
						


						// remove from table circle
						//lay phan tu tren bang
						int rowC = circle_table.getSelectedRow();
						//lay toa do(x,y)
						String strC = (String) circle_table.getValueAt(rowC, 0);
						strC = strC.substring(1, strC.length() - 1);
						String[] arrStrC = strC.split(",");
						int x = Integer.valueOf(arrStrC[0].trim());
						int y = Integer.valueOf(arrStrC[1].trim());
						//lay ban kinh
						int radius = (int) circle_table.getValueAt(rowC, 1);
						//xoa phan tu trong danh sach co chi so giong nhu tren
						for (AbstractCircle c : listCircle) {
							if (c.getX() == x && c.getY() == y && c.getRadius() == radius) {
								//xoa hinh tren nen ve~
								g.clearRect(x, y, radius, radius);
								//xoa phan tu trong danh sach
								listCircle.remove(c);
								break;
							}
						}
						
						//cap nhat lai danh sach
						circle_table = new JTable(new TableCircle(listCircle));
						circleScroll.setViewportView(circle_table);
						System.out.println("so hinh tron con lai:" + listCircle.size());
						
					}
				}
				if (!listRec.isEmpty()) {

					if (rectangle_table.getSelectedRow() != -1) {
						

						// remove from table rectangle
						int rowR = rectangle_table.getSelectedRow();
						String strR = (String) rectangle_table.getValueAt(rowR, 0);
						strR = strR.substring(1, strR.length() - 1);
						String[] arrStrR = strR.split(",");
						int x = Integer.valueOf(arrStrR[0].trim());
						int y = Integer.valueOf(arrStrR[1].trim());
						int height = (int) rectangle_table.getValueAt(rowR, 1);
						int width = (int) rectangle_table.getValueAt(rowR, 2);
						for (AbstractRectangle r : listRec) {
							if (r.getX() == x && r.getY() == y  && r.getHeight() == height && r.getWidth() == width) {
								g.clearRect(x, y, height, width);
								listRec.remove(r);
								break;
							}
						}

						rectangle_table = new JTable(new TableRectangle(listRec));
						recScroll.setViewportView(rectangle_table);

						System.out.println("so hinh cn con lai:" + listRec.size());
					}
				}
				// draw all again
				for (AbstractCircle c : listCircle) {

					c.draw(g);

				}
				// draw again after delete one

				for (AbstractRectangle r : listRec) {

					r.draw(g);

				}
			}
	});
		button_panel.add(removeButton);
		
		//Create Undon button
		Button undoButton = new Button("Undo");
		undoButton.setBounds(131, 10, 51, 22);
		button_panel.add(undoButton);
		
		//Create Redo button
		Button redoButton = new Button("Redo");
		redoButton.setBounds(188, 10, 51, 22);
		button_panel.add(redoButton);
		
		//Create Print button
		Button printButton = new Button("Print");
		printButton.setBounds(245, 10, 51, 22);
		button_panel.add(printButton);
		
		//Create D Panel(2D or 3D)
		Panel D_panel = new Panel();
		D_panel.setBackground(new Color(255, 0, 0));
		D_panel.setBounds(313, 0, 164, 37);
		button_panel.add(D_panel);
		D_panel.setLayout(null);
		
		//Create 3D radio buttton
		final JRadioButton radio3D = new JRadioButton("3D");
		radio3D.setBounds(7, 7, 73, 23);
		D_panel.add(radio3D);
		
		//Create 2D radio button
		final JRadioButton radio2D = new JRadioButton("2D");
		radio2D.setSelected(true);
		radio2D.setBounds(85, 7, 73, 23);
		D_panel.add(radio2D);
		
		//Create D Group Button contain 2D & 3D
		ButtonGroup buttonG1 = new ButtonGroup();
		buttonG1.add(radio2D); buttonG1.add(radio3D);
		JPanel type_shape_panel = new JPanel();
		type_shape_panel.setBackground(Color.ORANGE);
		type_shape_panel.setBounds(313, 40, 164, 37);
		button_panel.add(type_shape_panel);
		type_shape_panel.setLayout(null);
		
		//Create Circle Radio button
		final JRadioButton radioCircle = new JRadioButton("Circle");
		radioCircle.setSelected(true);
		radioCircle.setBounds(7, 7, 73, 23);
		type_shape_panel.add(radioCircle);
		
		//Create Rectangle Radio button
		final JRadioButton radioRectangle = new JRadioButton("Rectangle");
		radioRectangle.setBounds(85, 7, 73, 23);
		type_shape_panel.add(radioRectangle);
		
		//Create Type Shape Group contain Circle & Rectangle
		ButtonGroup buttonG2 = new ButtonGroup();
		buttonG2.add(radioCircle); buttonG2.add(radioRectangle);
		
		//Create Draw Panel
		draw_panel = new Panel();
		draw_panel.setBackground(new Color(143, 188, 143));
		draw_panel.setBounds(197, 77, 477, 247);
		frame.getContentPane().add(draw_panel);
		draw_panel.setLayout(null);
		draw_panel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				
				super.mouseClicked(e);
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				;
			}

			@Override
			public void mousePressed(MouseEvent e) {
				last = e.getPoint();
			}
			
			AbstractFactory f2d = new FactoryProducer().getFactory(typeFactory.F_2D);
			AbstractFactory f3d = new FactoryProducer().getFactory(typeFactory.F_3D);
			//Draw
			@Override
			public void mouseReleased(MouseEvent e) {
					
				int dx = Math.abs(present.x - last.x);
				int dy = Math.abs(present.y - last.y);
				x = last.x;
				y = last.y;
				int radius = (int) Math.sqrt(dx * dx + dy * dy);

					Graphics g = draw_panel.getGraphics();
					
					if (radio2D.isSelected()) {
						
						if (radioCircle.isSelected()) {
							// draw circle 2d
							f2d.getShapeC(typeShape.Circle, x, y, radius).draw(g);				
							
							listCircle.add(f2d.getShapeC(typeShape.Circle, dx, dy, radius));
							circle_table = new JTable(new TableCircle(listCircle));
							circleScroll.setViewportView(circle_table);
							System.out.println("so hinh tron dang ve co': "+listCircle.size());
				
						}else{	
							// draw rectangle 2d
							f2d.getShapeR(typeShape.Rectangle,x,y,dx,dy).draw(g);
							
							listRec.add(f2d.getShapeR(typeShape.Rectangle,x,y,dx,dy));
							rectangle_table = new JTable(new TableRectangle(listRec));
							recScroll.setViewportView(rectangle_table);
							System.out.println("so hinh cn dang ve co': "+listRec.size());
						}
					} else {
						if (radioCircle.isSelected()) {
							// draw circle 3d
							f3d.getShapeC(typeShape.Circle,x,y,radius).draw(g);			
							
							listCircle.add(f3d.getShapeC(typeShape.Circle,x,y,radius));
							circle_table = new JTable(new TableCircle(listCircle));
							circleScroll.setViewportView(circle_table);
							System.out.println("so hinh tron dang ve co': "+listCircle.size());
				
						}else{
							// draw rectangle 3d
							f3d.getShapeR(typeShape.Rectangle,x,y,dx,dy).draw(g);

							listRec.add(f3d.getShapeR(typeShape.Rectangle,x,y,dx,dy));
							rectangle_table = new JTable(new TableRectangle(listRec));
							recScroll.setViewportView(rectangle_table);
							System.out.println("so hinh cn dang ve co': "+listRec.size());
					}
					
				}

			}
			
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				
			}
			
			
		});
		draw_panel.addMouseMotionListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				present = e.getPoint();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				
			}

			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				
			}
			
		});
	}
}
