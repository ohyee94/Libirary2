package TMAPaint;

import java.awt.Color;
import java.awt.Graphics;

public class Circle3D extends AbstractCircle{
	
	public Circle3D(int x, int y, float radius) {
		super(x, y, (int) radius);
	}

	@Override
	void draw(Graphics g) {
		g.setColor(Color.GREEN);

		g.fillOval(getX(), getY(), getRadius(), getRadius());
		
		super.draw(g);
	}
}
