package TMAPaint;

import java.util.List;

import javax.swing.table.AbstractTableModel;


public class TableRectangle extends AbstractTableModel {
	
	String[] columnNames = { "Position", "Height", "Width" };
	Object[][] data;
	
	public TableRectangle(List<AbstractRectangle> listRectangle) {
		int length = 0;
		for (int i = 0; i < listRectangle.size(); i++) {		
				length++;
		}
		data = new Object[length][3];
		int i = 0;
		for (AbstractRectangle rectangle : listRectangle) {
				data[i][0] = "(" + rectangle.getX() + ", " + rectangle.getY() + ")";
				data[i][1] = rectangle.getHeight();
				data[i][2] = rectangle.getWidth();
				i++;
			}
		}

	@Override
	public int getColumnCount() {
		
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return data.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		
		return data[rowIndex][columnIndex];
	}

	public String getColumnName(int col) {
		return columnNames[col];
	}


	

	
}
