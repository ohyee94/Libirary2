package TMAPaint;

public class Factory2D extends AbstractFactory{
	
	
	
	@Override
	public AbstractCircle getShapeC(typeShape type,int x,int y,int radius) {
		type = typeShape.Circle;
			
		return new Circle2D(x,y,radius);		
	}
	
	@Override
	public AbstractRectangle getShapeR(typeShape type, int x, int y, int height, int width) {
		type = typeShape.Rectangle;
		return new Rectangle2D(x,y,height,width);
	}
	
}
