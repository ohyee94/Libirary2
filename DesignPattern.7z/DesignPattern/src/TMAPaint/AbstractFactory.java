package TMAPaint;



public abstract class AbstractFactory{

	public static enum typeShape{
		Circle,Rectangle;
	}
	public abstract AbstractCircle getShapeC(typeShape type,int x,int y,int radius);
	public abstract AbstractRectangle getShapeR(typeShape type,int x,int y,int height,int width);
	

}
