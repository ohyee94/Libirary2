package TMAPaint;

import java.awt.Graphics;

public abstract class AbstractCircle extends AbstractShape{
	private int radius;
	public AbstractCircle(int x, int y, int radius) {
		super(x, y);
		this.radius = radius;
	}
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	@Override
	void draw(Graphics g) {
	//	g.fillOval(getX(), getY(), getRadius(), getRadius());
		
	}
	
	
}
