package TMAPaint;

import java.awt.Graphics;

public abstract class AbstractRectangle extends AbstractShape{
	
	private int height;
	private int width;
	public AbstractRectangle(int x, int y, int height, int width) {
		super(x, y);
		this.height = height;
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	
	@Override
	void draw(Graphics g) {
	//	g.fillRect(getX(), getY(), getHeight(), getWidth());
		
	}

}
