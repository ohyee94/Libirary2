package TMAPaint;

import java.util.List;

import javax.swing.undo.AbstractUndoableEdit;


public class UndoPaint extends AbstractUndoableEdit{
	protected List<AbstractCircle> listCircle;
	protected AbstractCircle circle;
	protected List<AbstractRectangle> listRectangle;
	protected AbstractRectangle rectangle;

	public UndoPaint(List<AbstractCircle> listCircle, AbstractCircle circle) {
		this.listCircle =listCircle;
		this.circle = circle;
	}
	public UndoPaint(List<AbstractRectangle> listRectangle, AbstractRectangle rectangle) {
		this.listRectangle =listRectangle;
		this.rectangle = rectangle;
	}

	@Override
	public void undo() {

		if (!listCircle.isEmpty()) {
			super.undo();
			listCircle.remove(circle);
		}
		if (!listRectangle.isEmpty()) {
			super.undo();
			listRectangle.remove(rectangle);
		}
	}

	@Override
	public void redo() {
		super.redo();
		listCircle.add(circle);
		listRectangle.add(rectangle);
	}

}
