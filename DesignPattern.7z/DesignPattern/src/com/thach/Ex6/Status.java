package com.thach.Ex6;

public class Status {
 
	public static int btChoice = 0;

	public static final int ADD = 1;

	public static final int REMOE = 2;

	public static final int UNDO = 3;

	public static final int REDO = 4;

	public static final int PRINT = 5;

	public static int styleDraw = 0;

	public static final int DRAW_CIRCLE = 1;

	public static final int DRAW_RECT = 2;

	public static int style2D3D = 0;

	public static final int D2 = 1;

	public static final int D3 = 2;

}
